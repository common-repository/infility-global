!function(e){e(function(){e("#sortable").sortable({placeholder:"highlight"}),e("#sortable").disableSelection()})}(jQuery);
//# sourceMappingURL=engines.js.map